import React from 'react';
import '../styles/TakeQuizPage.css';

const TakeQuizPage = () => {
  return (
    <div className="take-quiz-page">
      <h2>Quiz Title</h2>
      <div className="timer">Time Remaining: 10:00</div>
      {/* Questions with options */}
      <div>
        {/* Map through questions */}
      </div>
      <button>Submit</button>
    </div>
  );
};

export default TakeQuizPage;

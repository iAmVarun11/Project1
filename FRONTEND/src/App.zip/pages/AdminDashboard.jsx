import React from 'react';
import '../styles/AdminDashboard.css';

const AdminDashboard = () => {
  return (
    <div className="admin-dashboard">
      <h2>Admin Dashboard</h2>
      {/* Platform usage stats */}
      <div>
        {/* Display stats */}
      </div>
    </div>
  );
};

export default AdminDashboard;

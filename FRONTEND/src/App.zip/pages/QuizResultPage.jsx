import React from 'react';
import '../styles/QuizResultPage.css';

const QuizResultPage = () => {
  return (
    <div className="quiz-result-page">
      <h2>Your Results</h2>
      {/* Score and correct/incorrect answers */}
      <div>
        {/* Display results */}
      </div>
      <button>Retry Quiz</button>
    </div>
  );
};

export default QuizResultPage;

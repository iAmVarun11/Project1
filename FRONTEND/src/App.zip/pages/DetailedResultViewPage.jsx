import React from 'react';
import '../styles/DetailedResultViewPage.css';

const DetailedResultViewPage = () => {
  return (
    <div className="detailed-result-view-page">
      <h2>Detailed Results</h2>
      {/* Show each question with student’s answer and correct answer */}
      <div>
        {/* Map through questions */}
      </div>
    </div>
  );
};

export default DetailedResultViewPage;
